# SciHub Pro Distribution Bundle

## Quick Start (Static Hosting)

This bundle contains pre-built static files ready for deployment.

### Deployment Options:

#### Simple HTTP Server (Testing)
```bash
python3 -m http.server 8080
```

#### Docker Deployment
```bash
docker build -t scihub-pro .
docker run -p 3000:3000 scihub-pro
```

## Cloud Deployment

See `deploy/` directory for scripts:
- deploy-gcp.sh - Google Cloud Run
- deploy-aws.sh - AWS ECS/Fargate
- deploy-azure.sh - Azure Container Apps

## Documentation

Full documentation available in `docs/` directory.

## Support

- Live Demo: https://testdemoqwenai2025-creator.github.io/scihub-pro-demo/
- GitHub: https://github.com/testdemoqwenai2025-creator/Demo2SciHub

MIT License - See LICENSE file for details.
